
README:

This folder contains sample code for Chapter 7,
"Working with Videos"


See individual Python source files for dependencies and 
instructions on running the code. 

See gpl.txt for license. 
