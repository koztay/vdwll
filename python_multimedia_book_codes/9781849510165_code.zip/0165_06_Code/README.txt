
README:

This folder contains sample code for Chapter 6,
"Audio Controls and Effects"

See individual Python source files for dependencies and 
instructions on running the code. 

See gpl.txt for license. 
