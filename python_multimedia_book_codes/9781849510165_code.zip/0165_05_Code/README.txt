
README:

This folder contains sample code for Chapter5, "Working with Audios"

See individual Python source files for dependencies and 
instructions on running the code. 

