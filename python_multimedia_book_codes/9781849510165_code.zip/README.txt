CHAPTER                                                                      CODE  
----------------------------------------------------------------------------------------------------- 
1				    CODE NOT PRESENT
2 				    CODE PRESENT
3				    CODE PRESENT
4				    CODE PRESENT
5				    CODE PRESENT
6				    CODE PRESENT
7				    CODE PRESENT
8				    CODE PRESENT
------------------------------------------------------------------------------------------------------