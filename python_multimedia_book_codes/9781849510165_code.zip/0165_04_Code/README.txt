
README:

This folder contains:
1. The images folder  
2. Sample code for Chapter 4,
"Fun With Animations" 

See individual Python source files for dependencies and 
instructions on running the code. 

See gpl.txt for license. 
