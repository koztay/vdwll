
README:

This folder contains:
1. Some icons
2. Sample code for Chapter 8, "GUI Based Media Players Using QT Phonon"


See individual Python source files for dependencies and 
instructions on running the code. 


