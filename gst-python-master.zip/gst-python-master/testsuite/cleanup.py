import pygst
pygst.require('0.10')
import gst

